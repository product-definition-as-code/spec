(set-logic QF_LIA)
(define-fun Step ((s Int) (u Int) (c Int) (d Int) (due Bool) (a Int) (o Int) (i Int) (auth Bool) (e Bool) (op Int) (ok Bool) (ns Int) (nu Int) (no Int)) Bool (and ok (= ns s) (= nu u) (= no o)))

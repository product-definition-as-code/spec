import sys,subprocess,json
from pathlib import Path
sys.path.insert(0,'/tmp/pdac-v040-g2/spec/docs/research/v0.4.0/evaluation');from isolation import namespace,environment
root=Path('/tmp/pdac-v040-g2-diagnostics');work=root/'work'
for label,flags in [('outer-userns',['--unshare-user']),('outer-userns-root',['--unshare-user','--uid','0','--gid','0']),('outer-userns-cap',['--unshare-user','--cap-add','CAP_SYS_ADMIN'])]:
 cmd=['codex','sandbox','-c','sandbox_mode="workspace-write"','--','python3','-c','print("SANDBOX_COMMAND_OK")'];ns=namespace(work,cmd,network=False);ns[1:1]=flags
 wrapped=['systemd-run','--user','--quiet','--wait','--pipe','--collect','-p','RuntimeMaxSec=30','-p','MemoryMax=2147483648','-p','TasksMax=64','--',*ns]
 r=subprocess.run(wrapped,env=environment(),capture_output=True,timeout=40);(root/(label+'.stdout')).write_bytes(r.stdout);(root/(label+'.stderr')).write_bytes(r.stderr);print(label,r.returncode,r.stdout.decode(),r.stderr.decode()[-1200:])

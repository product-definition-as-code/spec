import sys,subprocess,json
from pathlib import Path
sys.path.insert(0,'/tmp/pdac-v040-g2/spec/docs/research/v0.4.0/evaluation');from isolation import namespace,environment
root=Path('/tmp/pdac-v040-g2-diagnostics');work=root/'work'
commands=[('manager-env-fixed',['python3','-c','import os,json; from pathlib import Path; p=os.environ.get("TMPDIR"); print(json.dumps({"TMPDIR":p,"temp_exists":Path(p).is_dir(),"host_home_visible":Path("/home/juan").exists()}))']),('sandbox-fixed',['codex','sandbox','-c','sandbox_mode="workspace-write"','--','python3','-c','print("SANDBOX_COMMAND_OK")'])]
for label,cmd in commands:
 wrapped=['systemd-run','--user','--quiet','--wait','--pipe','--collect','-p','RuntimeMaxSec=30','-p','MemoryMax=2147483648','-p','TasksMax=64','--',*namespace(work,cmd,network=False)]
 r=subprocess.run(wrapped,env=environment(),capture_output=True,timeout=40);(root/(label+'.stdout')).write_bytes(r.stdout);(root/(label+'.stderr')).write_bytes(r.stderr);print(label,r.returncode,r.stdout.decode(),r.stderr.decode()[-1500:]);assert r.returncode==0
